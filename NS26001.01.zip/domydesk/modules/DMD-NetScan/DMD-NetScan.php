<?php
require_once __DIR__ . '/DMD-NetScan_lib.php';
$email = ns_require('module.view');
$cfg = ns_load_config($email);
$scan = ns_last_scan($email);
$permissions = ns_permissions_snapshot($email);
$infraModule = ns_detect_infra_module();
$infraMode = isset($cfg['infra']['mode']) ? (string)$cfg['infra']['mode'] : 'none';
$infraReady = !empty($infraModule['installed']) && (($infraMode === 'filedrop' && trim((string)$cfg['infra']['filedrop_path']) !== '') || ($infraMode === 'webhook' && preg_match('#^https?://#i', trim((string)$cfg['infra']['webhook_url']))));
$csrf = ns_csrf();
$uid = 'netscan_' . bin2hex(random_bytes(4));
$cssVersion = @filemtime(__DIR__ . '/DMD-NetScan.css') ?: time();
$jsVersion = @filemtime(__DIR__ . '/DMD-NetScan.js') ?: time();
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-NetScan';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$moduleWebPath = rtrim($moduleWebPath, '/');
$apiUrl = $moduleWebPath . '/DMD-NetScan_api.php';
$exportUrl = $moduleWebPath . '/DMD-NetScan_export.php';
$exportPdfUrl = $moduleWebPath . '/DMD-NetScan_export_pdf.php';
?>
<link rel="stylesheet" href="<?= ns_h($moduleWebPath) ?>/DMD-NetScan.css?v=<?= ns_h($cssVersion) ?>">
<div class="netscan" id="<?= ns_h($uid) ?>" data-csrf="<?= ns_h($csrf) ?>" data-api="<?= ns_h($apiUrl) ?>" data-export="<?= ns_h($exportUrl) ?>" data-export-pdf="<?= ns_h($exportPdfUrl) ?>">
  <div class="netscan-head">
    <div class="netscan-brand"><img src="<?= ns_h($moduleWebPath) ?>/icon.png" alt=""><div class="netscan-brand-copy"><span class="netscan-kicker">DoMyDesk 1.2.0</span><strong>DMD-NetScan</strong><small>Scanner réseau et inventaire rapide</small></div></div>
    <span class="netscan-state" data-state-label>Prêt</span>
  </div>

  <div class="netscan-toolbar">
    <button class="netscan-btn" type="button" data-open="results">Hôtes</button>
    <?php if ($permissions['actionhub.use']): ?><button class="netscan-btn" type="button" data-open="actionhub">⚡ ActionHub</button><?php endif; ?>
    <?php if ($permissions['scan.share']): ?><button class="netscan-btn" type="button" data-open="shares">Partages</button><?php endif; ?>
    <?php if ($permissions['logs.view']): ?><button class="netscan-btn" type="button" data-open="logs">Logs</button><?php endif; ?>
    <?php if ($permissions['scan.export']): ?><button class="netscan-btn" type="button" data-open="exports">Exports</button><?php endif; ?>
    <?php if ($permissions['scan.jobs']): ?><button class="netscan-btn" type="button" data-open="jobs">Planification</button><?php endif; ?>
    <span class="netscan-spacer"></span>
    <?php if ($permissions['infra.push']): ?>
      <?php if (empty($infraModule['installed'])): ?>
        <button class="netscan-btn" type="button" disabled title="DMD-Infra-IT n’est pas installé">DMD-Infra-IT absent</button>
      <?php elseif (!$infraReady): ?>
        <button class="netscan-btn" type="button" disabled title="DMD-Infra-IT est détecté, mais aucun import n’est configuré dans la CFG NetScan">Infra à configurer</button>
      <?php else: ?>
        <button class="netscan-btn" type="button" data-infra title="Cible : <?= ns_h(isset($infraModule['name'])?$infraModule['name']:'DMD-Infra-IT') ?>">Envoyer à DMD-Infra-IT</button>
      <?php endif; ?>
    <?php endif; ?>
  </div>

  <section class="netscan-card">
    <div class="netscan-form-grid">
      <label><span>Réseaux CIDR</span><input data-cidrs value="<?= ns_h(implode(', ', $cfg['cidrs'])) ?>" placeholder="192.168.0.0/24"></label>
      <label><span>Ports de découverte</span><input data-ports value="<?= ns_h(implode(',', $cfg['ports'])) ?>" placeholder="22,80,443,445,3389"></label>
      <label><span>Limite hôtes</span><input data-max type="number" min="16" max="4096" value="<?= (int)$cfg['max_hosts'] ?>"></label>
    </div>
    <div class="netscan-checks">
      <label class="netscan-check"><input data-resolve type="checkbox" <?= $cfg['resolve']?'checked':'' ?>><span>Reverse DNS</span></label>
      <label class="netscan-check"><input data-deep type="checkbox" <?= $cfg['deep']?'checked':'' ?>><span>Scan complet TCP 1–65535</span></label>
    </div>
    <div class="netscan-scan-actions">
      <?php if ($permissions['scan.configure']): ?><button class="netscan-btn" type="button" data-save>Enregistrer</button><?php endif; ?>
      <?php if ($permissions['scan.start']): ?><button class="netscan-btn netscan-btn--primary" type="button" data-start>Scanner</button><?php endif; ?>
      <?php if ($permissions['scan.stop']): ?><button class="netscan-btn" type="button" data-stop disabled>Stop</button><?php endif; ?>
      <?php if ($permissions['scan.arp']): ?><button class="netscan-btn" type="button" data-arp>ARP</button><?php endif; ?>
      <span class="netscan-inline-msg" data-msg>Prêt.</span>
    </div>
  </section>

  <div class="netscan-progress-wrap"><div class="netscan-progress"><span data-progress></span></div><span class="netscan-progress-label" data-progress-label>0 %</span></div>
  <div class="netscan-stats">
    <div class="netscan-stat is-ok"><span>Hôtes détectés</span><strong data-count><?= count(isset($scan['results'])?$scan['results']:array()) ?></strong></div>
    <div class="netscan-stat"><span>Réseau</span><strong data-network><?= ns_h(isset($scan['cidrs'][0])?$scan['cidrs'][0]:$cfg['cidrs'][0]) ?></strong></div>
    <div class="netscan-stat"><span>Dernier scan</span><strong data-last><?= ns_h(isset($scan['finished_at'])&&$scan['finished_at']?$scan['finished_at']:'—') ?></strong></div>
    <div class="netscan-stat"><span>État</span><strong data-status>Prêt</strong></div>
  </div>
  <section class="netscan-card netscan-card--tight netscan-preview">
    <div class="netscan-preview-head"><div><strong>Aperçu</strong><div class="netscan-muted"><?= $permissions['actionhub.use'] ? 'Clique un hôte pour le détail et son contexte ActionHub.' : 'Clique un hôte pour afficher son détail.' ?></div></div><button class="netscan-btn" type="button" data-open="results">Tout afficher</button></div>
    <div class="netscan-chips" data-preview></div>
  </section>
</div>
<script src="<?= ns_h($moduleWebPath) ?>/DMD-NetScan.js?v=<?= ns_h($jsVersion) ?>"></script>
