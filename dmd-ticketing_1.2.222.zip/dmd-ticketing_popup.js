/* DMD-Ticketing — fenetres du module uniquement (aucune modification du Core). */
(() => {
  'use strict';
  if (window.DMDTicketingPopup) return;
  const prefix = 'dmdtk-popup-';
  const active = new Set();
  let z = 1100000, cascade = 0;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const allowedUrl = (raw, forPage = false) => {
    try {
      const u = new URL(String(raw || ''), document.baseURI);
      if (!['http:', 'https:'].includes(u.protocol)) return null;
      if (forPage && (u.origin !== location.origin || !/^\/.*\/modules\/dmd-ticketing\/dmd-ticketing_overview(?:_access)?\.php$/.test(u.pathname))) return null;
      return u;
    } catch (_) { return null; }
  };
  const showError = (el, message) => { el.textContent = message; el.classList.add(prefix + 'notice'); };
  const raise = win => { win.style.zIndex = String(++z); };
  const workspace = () => {
    let w = window.innerWidth, h = window.innerHeight;
    document.querySelectorAll('.' + prefix + 'window').forEach(el => {
      if (el.classList.contains(prefix + 'mobile')) return;
      w = Math.max(w, Math.ceil(el.offsetLeft + el.offsetWidth + 16));
      h = Math.max(h, Math.ceil(el.offsetTop + el.offsetHeight + 16));
    });
    // Respecter les autres fenetres du dashboard; ne jamais imposer une largeur moindre.
    const html = document.documentElement, body = document.body;
    const oldW = parseFloat(html.style.minWidth) || 0, oldH = parseFloat(html.style.minHeight) || 0;
    if (w > oldW) html.style.minWidth = Math.ceil(w) + 'px';
    if (h > oldH) html.style.minHeight = Math.ceil(h) + 'px';
    if (w > (parseFloat(body.style.minWidth) || 0)) body.style.minWidth = Math.ceil(w) + 'px';
    if (h > (parseFloat(body.style.minHeight) || 0)) body.style.minHeight = Math.ceil(h) + 'px';
  };
  const keepViewport = (win) => {
    if (window.matchMedia('(max-width: 640px)').matches) {
      win.classList.add(prefix + 'mobile');
      return;
    }
    win.classList.remove(prefix + 'mobile');
  };
  function shell(title, {width = 960, height = 690, onClose = null} = {}) {
    const win = document.createElement('section');
    win.className = prefix + 'window';
    win.setAttribute('role', 'dialog');
    win.setAttribute('aria-label', String(title || 'Fenêtre Ticketing'));
    win.style.left = (Math.max(8, window.scrollX + 16) + ((cascade += 23) % 115)) + 'px';
    win.style.top = (Math.max(8, window.scrollY + 22) + (cascade % 90)) + 'px';
    win.style.width = Math.min(width, Math.max(300, innerWidth - 32)) + 'px';
    win.style.height = Math.min(height, Math.max(270, innerHeight - 32)) + 'px';
    win.innerHTML = `<div class="${prefix}head"><strong class="${prefix}title">${escape(title || 'DMD-Ticketing')}</strong><button type="button" class="${prefix}close" aria-label="Fermer la fenêtre" title="Fermer">×</button></div><div class="${prefix}body"></div><div class="${prefix}resize" role="separator" aria-label="Redimensionner" title="Redimensionner"></div>`;
    const close = () => { if (!active.has(win)) return; active.delete(win); try { if (onClose) onClose(); } finally { win.remove(); } };
    active.add(win);
    document.body.appendChild(win);
    raise(win);
    keepViewport(win);
    const head = win.querySelector('.' + prefix + 'head');
    win.querySelector('.' + prefix + 'close').addEventListener('click', close);
    win.addEventListener('pointerdown', () => raise(win));
    let drag = null;
    head.addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.target.closest('button') || win.classList.contains(prefix + 'mobile')) return;
      drag = {id:e.pointerId, x:e.pageX, y:e.pageY, left:win.offsetLeft, top:win.offsetTop};
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      win.style.left = Math.max(4, drag.left + e.pageX - drag.x) + 'px';
      win.style.top = Math.max(4, drag.top + e.pageY - drag.y) + 'px';
      workspace();
      if (e.clientX > innerWidth - 30 || e.clientY > innerHeight - 30) window.scrollBy(e.clientX > innerWidth - 30 ? 18 : 0, e.clientY > innerHeight - 30 ? 18 : 0);
    });
    const endDrag = e => { if (!drag) return; drag = null; try { head.releasePointerCapture(e.pointerId); } catch (_) {} };
    head.addEventListener('pointerup', endDrag);
    head.addEventListener('pointercancel', endDrag);
    const grip = win.querySelector('.' + prefix + 'resize');
    let resize = null;
    grip.addEventListener('pointerdown', e => {
      if (e.button !== 0 || win.classList.contains(prefix + 'mobile')) return;
      e.preventDefault();
      resize = {id:e.pointerId,x:e.clientX,y:e.clientY,w:win.offsetWidth,h:win.offsetHeight};
      grip.setPointerCapture(e.pointerId);
    });
    grip.addEventListener('pointermove', e => {
      if (!resize || e.pointerId !== resize.id) return;
      win.style.width = Math.max(300, resize.w + e.clientX - resize.x) + 'px';
      win.style.height = Math.max(250, resize.h + e.clientY - resize.y) + 'px';
      workspace();
    });
    const endResize = e => { if (!resize) return; resize = null; try { grip.releasePointerCapture(e.pointerId); } catch (_) {} };
    grip.addEventListener('pointerup', endResize);
    grip.addEventListener('pointercancel', endResize);
    win.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } });
    win.querySelector('.' + prefix + 'close').focus({preventScroll:true});
    workspace();
    return {win, body:win.querySelector('.' + prefix + 'body'), close};
  }
  function openPage(url, title) {
    const u = allowedUrl(url, true);
    if (!u) return false;
    u.searchParams.set('dmdtk_embedded', '1');
    const pane = shell(title || 'DMD-Ticketing', {width:1200, height:780});
    const frame = document.createElement('iframe');
    frame.className = prefix + 'frame';
    frame.title = title || 'DMD-Ticketing';
    frame.src = u.href;
    frame.setAttribute('referrerpolicy', 'same-origin');
    pane.body.appendChild(frame);
    return true;
  }
  function closeContainingFrame(childWindow) {
    for (const win of active) {
      const iframe = win.querySelector('iframe.' + prefix + 'frame');
      try { if (iframe && iframe.contentWindow === childWindow) { win.querySelector('.' + prefix + 'close').click(); return true; } } catch (_) {}
    }
    return false;
  }
  const extension = name => (String(name||'').match(/\.([a-zA-Z0-9]{1,12})$/) || [,''])[1].toLowerCase();
  async function openFile(rawUrl, name = 'Pièce jointe') {
    const u = allowedUrl(rawUrl);
    if (!u) return false;
    const fileName = String(name || 'Pièce jointe').replace(/[\r\n]/g,' ').slice(0,230);
    const ext = extension(fileName || u.pathname);
    let objectUrl = null, downloadedBlob = null;
    const pane = shell(fileName, {width:930,height:710,onClose:()=>{if(objectUrl)URL.revokeObjectURL(objectUrl);}});
    const toolbar = document.createElement('div');
    toolbar.className = prefix + 'toolbar';
    const filename = document.createElement('span');
    filename.className = prefix + 'filename';
    filename.textContent = fileName;
    const download = document.createElement('button');
    download.type = 'button'; download.textContent = 'Télécharger';
    download.className = prefix + 'download';
    toolbar.append(filename, download);
    const content = document.createElement('div');
    content.className = prefix + 'content';
    showError(content, 'Chargement de la pièce jointe…');
    pane.body.append(toolbar, content);
    const fetchFile = async () => {
      const response = await fetch(u.href, {credentials:'same-origin', cache:'no-store', redirect:'follow'});
      if (!response.ok) throw new Error('Fichier inaccessible ('+response.status+').');
      if (new URL(response.url).origin !== location.origin) throw new Error('Aperçu externe non autorisé.');
      return response.blob();
    };
    download.addEventListener('click', async () => {
      download.disabled = true;
      try {
        if (!downloadedBlob) downloadedBlob = await fetchFile();
        const blobUrl = URL.createObjectURL(downloadedBlob);
        const a = document.createElement('a');
        a.href = blobUrl; a.download = fileName; a.style.display = 'none';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
      } catch (err) { showError(content, err.message || 'Téléchargement impossible.'); }
      finally { download.disabled = false; }
    });
    const textTypes = new Set(['txt','log','json','jsonl','csv','xml','yaml','yml','md','ini','cfg','conf','ps1','cmd','bat','sh','html','htm','css','js','sql']);
    const imageTypes = new Set(['png','jpg','jpeg','webp','gif','bmp']);
    try {
      if (u.origin !== location.origin) { showError(content,'Aperçu externe non disponible dans DoMyDesk.'); return true; }
      const blob = await fetchFile();
      if (!active.has(pane.win)) return true;
      downloadedBlob = blob;
      content.textContent = '';
      content.classList.remove(prefix + 'notice');
      if (imageTypes.has(ext)) {
        objectUrl = URL.createObjectURL(new Blob([blob], {type: ext==='jpg'?'image/jpeg':'image/'+(ext==='jpeg'?'jpeg':ext)}));
        const img = document.createElement('img'); img.src = objectUrl; img.alt = fileName;
        img.onerror = () => showError(content, 'Aperçu impossible. Utilisez Télécharger.');
        content.appendChild(img);
      } else if (ext === 'pdf') {
        if (blob.size > 40*1024*1024) { showError(content,'Fichier volumineux. Utilisez Télécharger.'); return true; }
        const magic = await blob.slice(0,5).text();
        if (magic !== '%PDF-') { showError(content,'Le fichier ne contient pas un PDF valide.'); return true; }
        objectUrl = URL.createObjectURL(new Blob([blob],{type:'application/pdf'}));
        const iframe = document.createElement('iframe');iframe.title = fileName;iframe.src=objectUrl;iframe.setAttribute('referrerpolicy','no-referrer');
        content.appendChild(iframe);
      } else if (textTypes.has(ext)) {
        if (blob.size > 3*1024*1024) { showError(content,'Fichier texte volumineux. Utilisez Télécharger.'); return true; }
        let value = await blob.text();
        if (ext === 'json') { try {value=JSON.stringify(JSON.parse(value),null,2);} catch (_) {} }
        const pre = document.createElement('pre'); pre.textContent=value;content.appendChild(pre);
      } else showError(content,'Aperçu non disponible pour ce format. Utilisez Télécharger.');
    } catch (err) { if (active.has(pane.win)) showError(content, err.message || 'Pièce jointe inaccessible.'); }
    return true;
  }
  const bestHost = () => {
    try { if (window.parent !== window && window.parent.location.origin === location.origin && window.parent.DMDTicketingPopup) return window.parent.DMDTicketingPopup; } catch (_) {}
    return window.DMDTicketingPopup;
  };
  window.DMDTicketingPopup = {openPage,openFile,closeContainingFrame};
  document.addEventListener('click', e => {
    const page = e.target.closest('[data-dmdtk-page]');
    if (page) {
      const link = page.getAttribute('href') || page.dataset.dmdtkPage;
      if (!link) return;
      e.preventDefault();
      bestHost().openPage(link, page.dataset.dmdtkTitle || page.title || page.textContent.trim());
      return;
    }
    const file = e.target.closest('[data-dmdtk-file]');
    if (file) {
      const url = file.dataset.dmdtkUrl || file.getAttribute('href');
      if (!url) return;
      e.preventDefault();
      bestHost().openFile(url, file.dataset.dmdtkName || file.textContent.trim());
      return;
    }
    const back = e.target.closest('[data-dmdtk-close-embed]');
    if (back && new URL(location.href).searchParams.get('dmdtk_embedded') === '1') {
      e.preventDefault();
      try { if (parent && parent.DMDTicketingPopup && parent.DMDTicketingPopup.closeContainingFrame(window)) return; } catch (_) {}
      history.back();
    }
  });
})();
