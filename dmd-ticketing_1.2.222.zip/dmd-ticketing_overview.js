/* DMD-Ticketing — tableau de bord de supervision (lecture seule). */
(()=>{'use strict';
const state={tickets:[], data:null,mode:'overview',page:0,pageSize:12};
const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=v=>{if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'});};
const statusLabels={open:'Ouvert',in_progress:'En cours',waiting:'En attente',resolved:'Résolu',closed:'Fermé'};
const palette={open:'#3c91ed',in_progress:'#2dcaef',waiting:'#e8aa36',resolved:'#26bb80',closed:'#8394ad'};
const labels={overview:'Tableau de bord',tickets:'Tous les tickets accessibles',mine:'Mes tickets',urgent:'Tickets prioritaires',open:'Tickets ouverts',in_progress:'Tickets en cours',waiting:'Tickets en attente',resolved:'Tickets résolus',closed:'Tickets fermés',clients:'Tickets par client',statistics:'Statistiques'};
function duration(sec){if(sec===null||sec===undefined)return 'Non disponible';const min=Math.round(sec/60);if(min<60)return min+' min';const h=Math.floor(min/60),m=min%60;return h+' h '+String(m).padStart(2,'0')+' min';}
async function load(){
 const refresh=$('#ov-refresh');refresh.disabled=true;
 try {const r=await fetch('modules/dmd-ticketing/dmd-ticketing_overview_api.php',{credentials:'same-origin',cache:'no-store'});if(r.status===401||r.status===403){document.querySelector('#ov-main').innerHTML='<div class="ov-error">Accès refusé ou session expirée.</div>';return;}
 const data=await r.json();if(!r.ok||!data.ok)throw Error('Chargement impossible');state.data=data;state.tickets=data.tickets||[];
 $('#ov-scope').textContent=data.scope==='all'?'Supervision globale — tous les tickets':'Supervision des tickets accessibles à votre compte';
 const s=data.summary||{},c=s.statuses||{};
 [['total',s.total],['open',c.open],['in_progress',c.in_progress],['waiting',c.waiting],['resolved',c.resolved],['closed',c.closed],['urgent',s.urgent]].forEach(([k,v])=>$$(`[data-stat="${k}"]`).forEach(e=>e.textContent=String(v??0)));
 [['total',s.total],['open',c.open],['progress',c.in_progress],['waiting',c.waiting],['urgent',s.urgent]].forEach(([k,v])=>$$(`[data-head="${k}"]`).forEach(e=>e.textContent=String(v??0)));
 $('#ov-first-response').textContent=duration(s.first_response_seconds);
 $('#ov-first-response').title=String(s.answered_tickets||0)+' tickets pris en compte';
 const clients=[...new Set(state.tickets.map(t=>t.client).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
 const priorities=[...new Set(state.tickets.map(t=>t.priority).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
 const clientSel=$('#ov-client'),prioritySel=$('#ov-priority');
 const cval=clientSel.value,pval=prioritySel.value;
 clientSel.innerHTML='<option value="">Tous les clients</option>'+clients.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
 prioritySel.innerHTML='<option value="">Toutes les priorités</option>'+priorities.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
 clientSel.value=clients.includes(cval)?cval:'';prioritySel.value=priorities.includes(pval)?pval:'';
 renderChart(data.trend||[]);renderDonut(c);renderRanks('#ov-right-list',data.clients||{},'tickets actifs');renderRanks('#ov-owners',data.owners||{},'tickets');render();
 }catch(e){$('#ov-tbody').innerHTML='<tr><td colspan="6">Impossible de charger les tickets. Réessayez.</td></tr>';$('#ov-scope').textContent=e.message;}finally{refresh.disabled=false;}
}
function renderChart(points){const svg=$('#ov-trend');if(!points.length){svg.innerHTML='';return;}
 const W=690,H=172,top=13,bottom=148,left=27,right=675,max=Math.max(1,...points.map(p=>Number(p.count)||0));
 const xy=points.map((p,i)=>[left+(right-left)*(i/Math.max(points.length-1,1)),bottom-(Number(p.count)||0)/max*(bottom-top)]);
 const line=xy.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
 let h=`<defs><linearGradient id="ov-fill-grad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#2bc9ef" stop-opacity=".38"/><stop offset="100%" stop-color="#2bc9ef" stop-opacity="0"/></linearGradient></defs>`;
 for(let i=0;i<=4;i++){const y=bottom-(bottom-top)*i/4;h+=`<line x1="${left}" y1="${y}" x2="${right}" y2="${y}" stroke="#35516b" stroke-opacity=".52"/><text x="0" y="${y+4}" fill="#a9bdd3" font-size="11">${Math.round(max*i/4)}</text>`;}
 h+=`<path d="${line} L${right} ${bottom} L${left} ${bottom} Z" fill="url(#ov-fill-grad)"/><path d="${line}" fill="none" stroke="#2bc9ef" stroke-width="2.7" stroke-linecap="round"/>`;
 xy.forEach((p,i)=>{if(i%5===0||i===xy.length-1)h+=`<circle cx="${p[0]}" cy="${p[1]}" r="3.1" fill="#d7fbff"/><text x="${p[0]}" y="169" fill="#a9bdd3" text-anchor="middle" font-size="11">${esc(String(points[i].day).slice(5))}</text>`;});
 svg.innerHTML=h;
}
function renderDonut(counts){const total=Object.values(counts).reduce((a,b)=>a+Number(b||0),0);let angle=0;const parts=[];
 for(const [k,color] of Object.entries(palette)){const n=Number(counts[k]||0),percent=total?100*n/total:0;if(percent)parts.push(`${color} ${angle}% ${angle+percent}%`);angle+=percent;}
 $('#ov-donut').style.background=parts.length?'conic-gradient('+parts.join(',')+')':'conic-gradient(#2a4058 0 100%)';
 $('#ov-legend').innerHTML=Object.entries(palette).map(([k,color])=>`<div><i style="background:${color}"></i><span>${esc(statusLabels[k])}</span><b>${Number(counts[k]||0)}</b></div>`).join('');
}
function renderRanks(sel,values,unit){const el=$(sel),entries=Object.entries(values).slice(0,6);if(!entries.length){el.innerHTML='<p class="ov-muted">Aucune donnée disponible.</p>';return;}
 const max=Math.max(1,...entries.map(([,v])=>Number(v)));el.innerHTML=entries.map(([name,value],i)=>`<div class="ov-rank"><span class="ov-rank-n">${i+1}</span><span class="ov-rank-name" title="${esc(name)}">${esc(name)}</span><small>${value} ${unit}</small><div class="ov-rank-progress"><span style="width:${Math.round(Number(value)/max*100)}%"></span></div></div>`).join('');
}
function filter(){let arr=state.tickets.slice();const m=state.mode,status=$('#ov-status').value,client=$('#ov-client').value,priority=$('#ov-priority').value,q=$('#ov-search').value.trim().toLocaleLowerCase('fr-FR');
 if(m==='mine')arr=arr.filter(t=>t.owner===state.data.me);
 if(m==='urgent')arr=arr.filter(t=>t.urgent&&!['resolved','closed'].includes(t.status));
 if(['open','in_progress','waiting','resolved','closed'].includes(m))arr=arr.filter(t=>t.status===m);
 if(status)arr=arr.filter(t=>t.status===status);
 if(client)arr=arr.filter(t=>t.client===client);
 if(priority)arr=arr.filter(t=>t.priority===priority);
 if(q)arr=arr.filter(t=>[t.id,t.title,t.client,t.owner,t.category,t.priority].some(x=>String(x||'').toLocaleLowerCase('fr-FR').includes(q)));
 return arr;
}
function render(){if(!state.data)return;const rows=filter(),pages=Math.max(1,Math.ceil(rows.length/state.pageSize));state.page=Math.max(0,Math.min(state.page,pages-1));
 const show=rows.slice(state.page*state.pageSize,(state.page+1)*state.pageSize);
 $('#ov-tbody').innerHTML=show.length?show.map(t=>`<tr tabindex="0" data-ticket="${esc(t.id)}" title="Afficher le détail"><td class="ov-id">${esc(t.id)}</td><td class="ov-subject">${esc(t.title)}</td><td>${esc(t.client)}</td><td><span class="ov-tag ${t.urgent?'ov-tag-urgent':''}">${esc(t.priority||'—')}</span></td><td><span class="ov-status ov-status-${esc(t.status)}">${esc(statusLabels[t.status]||t.status)}</span></td><td>${esc(fmt(t.updated_at))}</td></tr>`).join(''):'<tr><td colspan="6" class="ov-empty">Aucun ticket pour ces filtres.</td></tr>';
 $('#ov-pagination-count').textContent=rows.length+' ticket(s) · Page '+(state.page+1)+' / '+pages;
 $('#ov-list-meta').textContent=rows.length+' résultat(s)';$('#ov-count-label').textContent=rows.length+' ticket(s) affichables';
 $('#ov-prev').disabled=state.page===0;$('#ov-next').disabled=state.page>=pages-1;
 $('#ov-heading-label').textContent=labels[state.mode]||'Tableau de bord';
 $('#ov-list-title').textContent=state.mode==='overview'?'Derniers tickets':labels[state.mode];
 $$('[data-section]').forEach(e=>e.classList.toggle('ov-nav-active',e.dataset.section===state.mode));
 $$('[data-ticket]').forEach(el=>{el.addEventListener('click',()=>detail(el.dataset.ticket));el.addEventListener('keydown',ev=>{if(ev.key==='Enter')detail(el.dataset.ticket);});});
}
async function detail(id){
 const t=state.tickets.find(x=>x.id===id);if(!t)return;
 const dlg=$('#ov-detail');state.detailId=id;
 const container=$('#ov-detail-body');
 container.innerHTML=`<h2>${esc(t.title)}</h2><p class="ov-detail-id">${esc(t.id)}</p><dl><dt>Client</dt><dd>${esc(t.client)}</dd><dt>Créé par</dt><dd>${esc(t.owner)}</dd><dt>Statut</dt><dd>${esc(statusLabels[t.status]||t.status)}</dd><dt>Priorité</dt><dd>${esc(t.priority||'—')}</dd><dt>Catégorie</dt><dd>${esc(t.category||'—')}</dd><dt>Création</dt><dd>${esc(fmt(t.created_at))}</dd><dt>Dernière activité</dt><dd>${esc(fmt(t.updated_at))}</dd><dt>Messages</dt><dd>${Number(t.message_count||0)}</dd></dl><h3>Échanges et pièces jointes</h3><div id="ov-detail-messages" aria-live="polite"><p class="ov-muted">Chargement des messages…</p></div><p class="ov-muted">Consultation uniquement. La modification des tickets reste dans le module DoMyDesk.</p>`;
 if(!dlg.open)dlg.showModal();
 try{
  const url='modules/dmd-ticketing/dmd-ticketing_overview_api.php?action=detail&id='+encodeURIComponent(id);
  const response=await fetch(url,{credentials:'same-origin',cache:'no-store'});
  const data=await response.json();
  if(!response.ok||!data.ok||data.id!==id)throw Error('Accès impossible aux échanges du ticket.');
  if(!dlg.open||state.detailId!==id)return;
  const messages=Array.isArray(data.messages)?data.messages:[];
  const target=$('#ov-detail-messages');if(!target)return;
  target.innerHTML=messages.length?messages.map(m=>{
   const files=Array.isArray(m.attachments)?m.attachments:[];
   const fileHtml=files.length?`<ul class="ov-detail-files">${files.map(a=>{
    const name=esc(a.name||'Fichier joint');
    return a.download_url?`<li><button type="button" class="ov-file-link" data-ov-file-url="${esc(a.download_url)}" data-ov-file-name="${name}">📎 ${name} — Aperçu</button></li>`
                         :`<li class="ov-muted">📎 ${name} — Fichier non disponible localement</li>`;
   }).join('')}</ul>`:'';
   return `<article class="ov-detail-message"><div class="ov-detail-message-head"><strong>${esc(m.by||'Intervenant')}</strong><time>${esc(fmt(m.at))}</time></div><p class="ov-detail-message-text">${esc(m.text||'')}</p>${fileHtml}</article>`;
  }).join(''):'<p class="ov-muted">Aucun message disponible.</p>';
 }catch(e){if(dlg.open&&state.detailId===id){const target=$('#ov-detail-messages');if(target)target.innerHTML='<p class="ov-error">Impossible de charger les messages et leurs pièces jointes.</p>';}}
}
// Aperçu en fenêtre interne de la vue globale, sans toucher à sa navigation.
function previewOverviewFile(name, url){
 const fileName=String(name||'Pièce jointe');
 let fileUrl;
 try{fileUrl=new URL(String(url||''),document.baseURI);if(fileUrl.origin!==location.origin||!['http:','https:'].includes(fileUrl.protocol))return;}catch(_){return;}
 const isImage=/\.(?:jpe?g|png|gif|webp|bmp)$/i.test(fileName);
 const isPdf=/\.pdf$/i.test(fileName);
 const isText=/\.(?:txt|log|json|jsonl|csv|md|xml|yaml|yml|ini|cfg|conf)$/i.test(fileName);
 const dlg=document.createElement('dialog');
 dlg.className='ov-detail';
 dlg.setAttribute('aria-label','Aperçu — '+fileName);
 dlg.style.cssText='width:min(1000px,calc(100vw - 24px));height:min(80vh,750px);max-height:calc(100vh - 24px);min-width:min(320px,calc(100vw - 24px));min-height:240px;padding:0;resize:both;overflow:hidden;';
 dlg.innerHTML=`<div style="height:100%;display:flex;flex-direction:column;min-height:0;">
   <div data-ov-file-drag style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-bottom:1px solid var(--ov-border);cursor:move;touch-action:none;">
    <strong style="min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(fileName)}</strong>
    <button type="button" class="ov-btn" data-ov-file-close aria-label="Fermer">×</button>
   </div>
   <div data-ov-file-stage style="flex:1;min-height:0;overflow:auto;display:flex;align-items:center;justify-content:center;background:var(--ov-panel);">Chargement de l’aperçu…</div>
   <div style="padding:8px 12px;border-top:1px solid var(--ov-border);display:flex;justify-content:flex-end;">
    <button type="button" class="ov-btn" data-ov-file-download>Télécharger</button>
   </div>
  </div>`;
 $('.dmd-ov-page').appendChild(dlg);
 let objectUrl='';
 const controller=new AbortController();
 dlg.addEventListener('close',()=>{controller.abort();if(objectUrl)URL.revokeObjectURL(objectUrl);dlg.remove();},{once:true});
 dlg.querySelector('[data-ov-file-close]').onclick=()=>dlg.close();
 dlg.addEventListener('click',e=>{if(e.target===dlg)dlg.close();});
 const stage=dlg.querySelector('[data-ov-file-stage]');
 const download=dlg.querySelector('[data-ov-file-download]');
 download.onclick=async()=>{
  download.disabled=true;
  try{
   const r=await fetch(fileUrl.href,{credentials:'same-origin',signal:controller.signal});
   if(!r.ok)throw new Error('Fichier indisponible ('+r.status+').');
   const blobUrl=URL.createObjectURL(await r.blob());
   const a=document.createElement('a');a.href=blobUrl;a.download=fileName;document.body.appendChild(a);a.click();a.remove();
   setTimeout(()=>URL.revokeObjectURL(blobUrl),60000);
  }catch(e){if(e.name!=='AbortError')stage.textContent='Téléchargement impossible : '+e.message;}finally{download.disabled=false;}
 };
 // La vue globale conserve son propre cadre, et non une nouvelle fenêtre du navigateur.
 const handle=dlg.querySelector('[data-ov-file-drag]');
 let dragging=false,x=0,y=0,initialLeft=0,initialTop=0;
 handle.addEventListener('pointerdown',e=>{
  if(e.target.closest('button'))return;
  const r=dlg.getBoundingClientRect();
  dlg.style.margin='0';dlg.style.left=r.left+'px';dlg.style.top=r.top+'px';dlg.style.right='auto';dlg.style.bottom='auto';
  dragging=true;x=e.clientX;y=e.clientY;initialLeft=r.left;initialTop=r.top;
  handle.setPointerCapture(e.pointerId);
 });
 handle.addEventListener('pointermove',e=>{
  if(!dragging)return;
  dlg.style.left=Math.max(0,Math.min(window.innerWidth-60,initialLeft+e.clientX-x))+'px';
  dlg.style.top=Math.max(0,Math.min(window.innerHeight-50,initialTop+e.clientY-y))+'px';
 });
 const stop=e=>{dragging=false;try{handle.releasePointerCapture(e.pointerId);}catch(_){}};
 handle.addEventListener('pointerup',stop);handle.addEventListener('pointercancel',stop);
 dlg.showModal();
 if(!isImage&&!isPdf&&!isText){stage.textContent='Aperçu non disponible pour ce format. Utilisez Télécharger.';return;}
 (async()=>{
  try{
   const r=await fetch(fileUrl.href,{credentials:'same-origin',signal:controller.signal});
   if(!r.ok)throw new Error('Fichier indisponible ('+r.status+').');
   if(!dlg.isConnected)return;
   stage.replaceChildren();
   if(isPdf||isImage){
    const data=await r.blob();if(!dlg.isConnected)return;
    const mime=isPdf?'application/pdf':({'jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png','gif':'image/gif','webp':'image/webp','bmp':'image/bmp'}[fileName.split('.').pop().toLowerCase()]||'application/octet-stream');
    objectUrl=URL.createObjectURL(new Blob([data],{type:mime}));
    const viewer=document.createElement(isPdf?'iframe':'img');viewer.src=objectUrl;
    viewer.style.cssText=isPdf?'width:100%;height:100%;border:0;':'display:block;max-width:100%;max-height:100%;object-fit:contain;';
    if(isPdf)stage.style.padding='0';else stage.style.padding='12px';
    stage.appendChild(viewer);
   }else{
    const content=await r.text();if(!dlg.isConnected)return;
    const pre=document.createElement('pre');pre.style.cssText='width:100%;height:100%;padding:12px;margin:0;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;text-align:left;font:12px/1.5 monospace;color:var(--ov-text)';
    pre.textContent=content.length>2000000?content.slice(0,2000000)+'\n\n[Aperçu limité à 2 Mo]':content;
    stage.appendChild(pre);
   }
  }catch(e){if(e.name!=='AbortError'&&dlg.isConnected)stage.textContent='Aperçu impossible : '+e.message;}
 })();
}
$$('[data-section]').forEach(b=>b.addEventListener('click',()=>{state.mode=b.dataset.section;state.page=0;render();if(window.innerWidth<=750)window.scrollTo({top:0,behavior:'smooth'});}));
['#ov-search','#ov-status','#ov-client','#ov-priority'].forEach(s=>$(s).addEventListener(s==='#ov-search'?'input':'change',()=>{state.page=0;render();}));
$('#ov-clear').addEventListener('click',()=>{$('#ov-search').value='';$('#ov-status').value='';$('#ov-client').value='';$('#ov-priority').value='';state.page=0;render();});
$('#ov-prev').addEventListener('click',()=>{state.page--;render();});$('#ov-next').addEventListener('click',()=>{state.page++;render();});
$('#ov-refresh').addEventListener('click',load);
$('#ov-detail').addEventListener('click',e=>{const b=e.target.closest('[data-ov-file-url]');if(b){e.preventDefault();previewOverviewFile(b.dataset.ovFileName,b.dataset.ovFileUrl);return;}if(e.target.id==='ov-detail')e.target.close();});
load();
})();
